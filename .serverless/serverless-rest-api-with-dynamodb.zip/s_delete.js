var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'coreyb220',
applicationName: 'serverless-todo',
appUid: 'yKFzFW78qcTpxmfJRD',
tenantUid: 'gn5T94fv1YJghk34Bx',
deploymentUid: '7a055f6e-db82-4cbc-8408-33804963629c',
serviceName: 'serverless-rest-api-with-dynamodb',
stageName: 'dev',
pluginVersion: '3.2.3'})
const handlerWrapperArgs = { functionName: 'serverless-rest-api-with-dynamodb-dev-delete', timeout: 6}
try {
  const userHandler = require('./todos/delete.js')
  module.exports.handler = serverlessSDK.handler(userHandler.delete, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
