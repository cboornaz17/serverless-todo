var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'coreyb220',
applicationName: 'serverless-todo',
appUid: 'yKFzFW78qcTpxmfJRD',
tenantUid: 'gn5T94fv1YJghk34Bx',
deploymentUid: '6f262a8b-bb39-42cf-aea7-9541b5bd9e68',
serviceName: 'serverless-rest-api-with-dynamodb',
stageName: 'dev',
pluginVersion: '3.2.3'})
const handlerWrapperArgs = { functionName: 'serverless-rest-api-with-dynamodb-dev-list', timeout: 6}
try {
  const userHandler = require('./todos/list.js')
  module.exports.handler = serverlessSDK.handler(userHandler.list, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
