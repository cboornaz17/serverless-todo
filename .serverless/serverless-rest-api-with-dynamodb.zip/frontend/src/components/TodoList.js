import React from 'react';
import API from '../api';
import Todo  from '../components/Todo';


class TodoList extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            todos: [],

            inputText: "",
        }
    }
    
    componentDidMount = () => {
        /*
        API.getTodos().then((response) => {
            if (response.success) {
                this.setState({
                    todos: response.data,
                })
            } else {

            }
        });
        */

       // set demo todos to test styles 
       this.setState({
            todos: [{
                    checked: false,
                    text: "first todo"
                }, {
                    checked: false,
                    text: "second todo"
                }
            ]
       });   
    }

    handleRemove = () => {

    }

    handleSubmitNew = () => {
        const newTodo= {
            text: this.state.inputText
        };
        API.addTodo(newTodo).then((response) => {
            if (response.success) {
                this.state.todos.push(newTodo);
            } 
            else {

            }
        })
    }

    renderTodos = () => {
        var ret =
        this.state.todos.map((todo) => {
            return (<li>
                <Todo 
                    text={todo.text}
                    checked={todo.checked}
                />
            </li> );
        });

        if (ret.length !== 0) {
            return <ul>{ret}</ul>
        }

        return <div>Loading</div>
    }

    addTodo = () => {
        this.setState({
            renderInput: true,
        });
    }

    handleInputChange = (event) => {
        this.setState({
            inputText: event.target.value
        })
    }

    renderInput = () => {
        return (
            <div>
                <input 
                    value={this.state.inputText} 
                    onChange={this.handleInputChange}
                />
                <button 
                    className={"btn btn-secondary"}
                    onClick={this.handleSubmitNew}
                >
                    submit
                </button>
            </div>
        );
    }

    render () {
        return (
            <div>TodoList
                {this.renderTodos()}
                {!this.state.renderInput &&
                    <button className={"btn btn-secondary"} onClick={this.addTodo.bind(this)}>add</button>
                }
                {this.state.renderInput && 
                    this.renderInput()
                }
            </div>
        )
    }
}


export default TodoList;